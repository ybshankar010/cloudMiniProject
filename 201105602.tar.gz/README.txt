execute the scripth file that is provided to get the required output.

./script.sh machines Images Vm_types
